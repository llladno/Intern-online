import { defineStore } from 'pinia'
import { $api } from '@/api'
import UserService from '@/api/userService'
import { usePopupStore } from '@/stores/PopupStore'
import type { UserRegistrationI } from '@/types/userI'
import OrganisationService from '@/api/organisationService'
import type { OrganisationProfileUpdateI } from '@/types/account/organisation'
import { useDataStore } from '@/stores/data/DataStore'

export const useOrganisationStore = defineStore('organisationStore', () => {
  function updateOrganisationProfile(updatedData: OrganisationProfileUpdateI) {
    try {
      return OrganisationService.patchOrganisation(updatedData)
    } catch (e) {
      console.log(e)
    }
  }

 async function getOrganisationProfile() {
    try {
      const organisationProfile = ( await OrganisationService.getOrganisation()).data
      const form = useDataStore().organisationForm()
      return
    } catch (e) {
      console.log(e)
    }
  }

  return { updateOrganisationProfile, getOrganisationProfile }
})
