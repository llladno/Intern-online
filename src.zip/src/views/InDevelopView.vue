<script setup lang="ts">
import InDevelop from '@/components/pages/develop/InDevelop.vue'
</script>

<template>
  <in-develop />
</template>

<style scoped></style>
