export interface AccountProfileI {
  id: number
  phone_number: string
  updated_at: string
}
