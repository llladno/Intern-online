<template>
  <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="17" cy="17" r="17" fill="white" />
    <path
      d="M19 14.375C19 15.7557 17.8807 16.875 16.5 16.875C15.1193 16.875 14 15.7557 14 14.375C14 12.9943 15.1193 11.875 16.5 11.875C17.8807 11.875 19 12.9943 19 14.375Z"
      stroke="#7862EB"
      stroke-width="1.3"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M16.5 18.75C14.0838 18.75 12.125 20.7088 12.125 23.125H20.875C20.875 20.7088 18.9162 18.75 16.5 18.75Z"
      stroke="#7862EB"
      stroke-width="1.3"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
