<script setup lang="ts"></script>

<template>
  <svg
    class="dropdown-button"
    width="40"
    height="40"
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g filter="url(#filter0_d_6189_553)">
      <rect x="2" y="1" width="36" height="36" rx="7" fill="white" />
      <rect x="2.5" y="1.5" width="35" height="35" rx="6.5" stroke="#E4E4E7" />
      <circle cx="14" cy="19" r="1.5" fill="#7862EB" />
      <circle cx="20" cy="19" r="1.5" fill="#7862EB" />
      <circle cx="26" cy="19" r="1.5" fill="#7862EB" />
    </g>
    <defs>
      <filter
        id="filter0_d_6189_553"
        x="0"
        y="0"
        width="40"
        height="40"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feColorMatrix
          in="SourceAlpha"
          type="matrix"
          values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          result="hardAlpha"
        />
        <feOffset dy="1" />
        <feGaussianBlur stdDeviation="1" />
        <feColorMatrix
          type="matrix"
          values="0 0 0 0 0.0627451 0 0 0 0 0.0941176 0 0 0 0 0.156863 0 0 0 0.05 0"
        />
        <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_6189_553" />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="effect1_dropShadow_6189_553"
          result="shape"
        />
      </filter>
    </defs>
  </svg>
</template>

<style scoped></style>
