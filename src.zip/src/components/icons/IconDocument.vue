<script setup lang="ts"></script>

<template>
  <svg width="17" height="23" viewBox="0 0 17 23" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M16 6.88V21C16 21.5523 15.5523 22 15 22H2C1.44772 22 1 21.5523 1 21V2C1 1.44772 1.44771 1 2 1H10.5833M16 6.88H11.5833C11.031 6.88 10.5833 6.43228 10.5833 5.88V1M16 6.88L10.5833 1M5.16667 11.5H12.25M5.16667 13.6H12.25M5.16667 15.28H12.25M5.16667 17.38H10.5833"
      stroke="#7862EB"
    />
  </svg>
</template>

<style scoped lang="scss"></style>
