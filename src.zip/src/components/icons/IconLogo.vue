<template>
  <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M0 20C0 8.95431 8.95431 0 20 0C31.0457 0 40 8.95431 40 20C40 31.0457 31.0457 40 20 40C8.95431 40 0 31.0457 0 20Z"
      fill="#7D52F4"
    />
    <path
      d="M24.0273 5.26437L20.9578 4.4447L18.3712 14.0655L16.0359 5.37978L12.9664 6.19944L15.4895 15.5837L9.20501 9.32057L6.95801 11.5599L13.8513 18.4299L5.2668 16.1375L4.44434 19.1965L13.824 21.7012C13.7166 21.2396 13.6598 20.7586 13.6598 20.2644C13.6598 16.7663 16.5053 13.9305 20.0153 13.9305C23.5254 13.9305 26.3708 16.7663 26.3708 20.2644C26.3708 20.7554 26.3147 21.2335 26.2086 21.6924L34.733 23.9687L35.5554 20.9097L26.1385 18.395L34.7236 16.1024L33.9011 13.0434L24.4845 15.5579L30.769 9.29486L28.522 7.05549L21.7243 13.8301L24.0273 5.26437Z"
      fill="url(#paint0_linear_8689_3029)"
      fill-opacity="0.88"
    />
    <path
      d="M26.2003 21.7282C25.9372 22.837 25.3816 23.8331 24.6193 24.6312L30.7948 30.7858L33.0418 28.5464L26.2003 21.7282Z"
      fill="url(#paint1_linear_8689_3029)"
      fill-opacity="0.88"
    />
    <path
      d="M24.5569 24.6954C23.7854 25.4807 22.8104 26.0668 21.717 26.3688L23.9642 34.7268L27.0336 33.9071L24.5569 24.6954Z"
      fill="url(#paint2_linear_8689_3029)"
      fill-opacity="0.88"
    />
    <path
      d="M21.6024 26.3994C21.0951 26.5293 20.5634 26.5984 20.0155 26.5984C19.4285 26.5984 18.86 26.5191 18.3203 26.3706L16.0711 34.7362L19.1406 35.5558L21.6024 26.3994Z"
      fill="url(#paint3_linear_8689_3029)"
      fill-opacity="0.88"
    />
    <path
      d="M18.2118 26.34C17.1351 26.0229 16.1774 25.4294 15.4217 24.6418L9.23094 30.8116L11.4779 33.0509L18.2118 26.34Z"
      fill="url(#paint4_linear_8689_3029)"
      fill-opacity="0.88"
    />
    <path
      d="M15.3699 24.5873C14.627 23.7947 14.086 22.8119 13.8284 21.7202L5.27621 24.004L6.09866 27.063L15.3699 24.5873Z"
      fill="url(#paint5_linear_8689_3029)"
      fill-opacity="0.88"
    />
    <defs>
      <linearGradient
        id="paint0_linear_8689_3029"
        x1="19.9999"
        y1="4.4447"
        x2="19.9999"
        y2="51.6202"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.313079" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="paint1_linear_8689_3029"
        x1="19.9999"
        y1="4.4447"
        x2="19.9999"
        y2="51.6202"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.313079" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="paint2_linear_8689_3029"
        x1="19.9999"
        y1="4.4447"
        x2="19.9999"
        y2="51.6202"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.313079" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="paint3_linear_8689_3029"
        x1="19.9999"
        y1="4.4447"
        x2="19.9999"
        y2="51.6202"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.313079" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="paint4_linear_8689_3029"
        x1="19.9999"
        y1="4.4447"
        x2="19.9999"
        y2="51.6202"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.313079" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="paint5_linear_8689_3029"
        x1="19.9999"
        y1="4.4447"
        x2="19.9999"
        y2="51.6202"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.313079" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
    </defs>
  </svg>
</template>
