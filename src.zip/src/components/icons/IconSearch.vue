<template>
  <svg
    class="search"
    width="15.002930"
    height="15.003052"
    viewBox="0 0 15.0029 15.0031"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
  >
    <g opacity="0.800000">
      <path
        id="Icon"
        d="M6 11.25C3.1 11.25 0.75 8.89 0.75 6C0.75 3.1 3.1 0.75 6 0.75C8.89 0.75 11.25 3.1 11.25 6C11.25 8.89 8.89 11.25 6 11.25ZM14.25 14.25L9.75 9.75"
        stroke="#28282D"
        stroke-opacity="1.000000"
        stroke-width="1.500000"
        stroke-linejoin="round"
        stroke-linecap="round"
      />
    </g>
  </svg>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
.search {
  position: absolute;
  top: 50%;
  left: 13px;
  transform: translateY(-25%);
}
</style>
